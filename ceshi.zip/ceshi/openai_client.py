"""
独立的OpenAI客户端模块
支持OpenAI兼容的API
"""

import openai
import json
import logging
from typing import List, Dict, Any, Optional
import asyncio
import aiohttp
import numpy as np


class OpenAIClient:
    """OpenAI客户端"""
    
    def __init__(self, config: Dict[str, Any]):
        self.llm_config = config['llm']
        self.embedding_config = config['embedding']
        self.logger = logging.getLogger(__name__)
        
        # 初始化OpenAI客户端
        self.llm_client = openai.OpenAI(
            api_key=self.llm_config['api_key'],
            base_url=self.llm_config['base_url']
        )
        
        self.embedding_client = openai.OpenAI(
            api_key=self.embedding_config['api_key'],
            base_url=self.embedding_config['base_url']
        )
    
    async def generate_text(self, prompt: str, **kwargs) -> str:
        """生成文本"""
        try:
            response = self.llm_client.chat.completions.create(
                model=self.llm_config['model'],
                messages=[{"role": "user", "content": prompt}],
                temperature=kwargs.get('temperature', self.llm_config['temperature']),
                max_tokens=kwargs.get('max_tokens', self.llm_config['max_tokens'])
            )
            return response.choices[0].message.content
        except Exception as e:
            self.logger.error(f"文本生成失败: {e}")
            raise
    
    async def generate_embedding(self, text: str) -> List[float]:
        """生成向量嵌入"""
        try:
            response = self.embedding_client.embeddings.create(
                model=self.embedding_config['model'],
                input=text
            )
            return response.data[0].embedding
        except Exception as e:
            self.logger.error(f"向量生成失败: {e}")
            raise
    
    async def batch_generate_embeddings(self, texts: List[str], batch_size: int = 100) -> List[List[float]]:
        """批量生成向量嵌入"""
        embeddings = []
        
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            try:
                response = self.embedding_client.embeddings.create(
                    model=self.embedding_config['model'],
                    input=batch
                )
                batch_embeddings = [item.embedding for item in response.data]
                embeddings.extend(batch_embeddings)
                
                self.logger.info(f"已生成 {len(embeddings)}/{len(texts)} 个向量")
                
                # 避免API限制，添加延迟
                await asyncio.sleep(0.1)
                
            except Exception as e:
                self.logger.error(f"批量向量生成失败: {e}")
                # 为失败的批次添加零向量
                zero_embedding = [0.0] * 1536  # OpenAI默认维度
                embeddings.extend([zero_embedding] * len(batch))
        
        return embeddings
    
    async def extract_entities(self, text: str, entity_types: List[str]) -> List[Dict[str, Any]]:
        """提取实体"""
        prompt = f"""
从以下文本中提取实体，返回JSON格式：

文本：{text}

请提取以下类型的实体：{', '.join(entity_types)}

返回格式：
{{
    "entities": [
        {{
            "name": "实体名称",
            "type": "实体类型",
            "description": "实体描述"
        }}
    ]
}}

只返回JSON，不要其他内容：
"""
        
        try:
            response = await self.generate_text(prompt)
            # 清理响应，提取JSON部分
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            if json_start != -1 and json_end != -1:
                json_str = response[json_start:json_end]
                result = json.loads(json_str)
                return result.get('entities', [])
            else:
                return []
        except Exception as e:
            self.logger.error(f"实体提取失败: {e}")
            return []
    
    async def extract_relations(self, text: str, entities: List[Dict[str, Any]], 
                              relation_types: List[str]) -> List[Dict[str, Any]]:
        """提取关系"""
        if len(entities) < 2:
            return []
        
        entity_names = [e['name'] for e in entities]
        
        prompt = f"""
从以下文本中提取实体间的关系，返回JSON格式：

文本：{text}
实体：{', '.join(entity_names)}

请提取以下类型的关系：{', '.join(relation_types)}

返回格式：
{{
    "relations": [
        {{
            "subject": "主体实体",
            "relation": "关系类型",
            "object": "客体实体",
            "confidence": 0.8,
            "description": "关系描述"
        }}
    ]
}}

只返回JSON，不要其他内容：
"""
        
        try:
            response = await self.generate_text(prompt)
            # 清理响应，提取JSON部分
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            if json_start != -1 and json_end != -1:
                json_str = response[json_start:json_end]
                result = json.loads(json_str)
                return result.get('relations', [])
            else:
                return []
        except Exception as e:
            self.logger.error(f"关系提取失败: {e}")
            return []
    
    async def answer_question(self, question: str, context: str) -> str:
        """基于上下文回答问题"""
        prompt = f"""
基于以下上下文信息回答问题：

上下文：
{context}

问题：{question}

请根据上下文信息提供准确、完整的答案。如果上下文中没有足够信息回答问题，请说明。

答案：
"""
        
        try:
            return await self.generate_text(prompt)
        except Exception as e:
            self.logger.error(f"问答失败: {e}")
            return "抱歉，无法生成答案。"
    
    async def extract_keywords(self, text: str, max_keywords: int = 10) -> List[str]:
        """提取关键词"""
        prompt = f"""
从以下文本中提取关键词，返回JSON格式：

文本：{text}

请提取最重要的{max_keywords}个关键词。

返回格式：
{{
    "keywords": ["关键词1", "关键词2", "关键词3"]
}}

只返回JSON，不要其他内容：
"""
        
        try:
            response = await self.generate_text(prompt)
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            if json_start != -1 and json_end != -1:
                json_str = response[json_start:json_end]
                result = json.loads(json_str)
                return result.get('keywords', [])
            else:
                return []
        except Exception as e:
            self.logger.error(f"关键词提取失败: {e}")
            return []