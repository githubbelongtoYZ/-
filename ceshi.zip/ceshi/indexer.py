"""
独立的NetOperatorQA知识图谱索引构建器
不依赖KAG源代码
"""

import logging
import asyncio
import toml
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
from datetime import datetime
from collections import defaultdict, Counter
import numpy as np

from database import DatabaseManager
from openai_client import OpenAIClient
from vector_store import VectorStore


class NetOperatorQAIndexer:
    """NetOperatorQA知识图谱索引构建器"""
    
    def __init__(self, config_path: str):
        """初始化索引构建器"""
        self.config = self._load_config(config_path)
        self.logger = self._setup_logging()
        
        # 初始化组件
        self.db = DatabaseManager(self.config)
        self.openai_client = OpenAIClient(self.config)
        self.vector_store = VectorStore(self.config)
        
        # 索引统计
        self.index_stats = {
            'entities_processed': 0,
            'relations_processed': 0,
            'entity_clusters': 0,
            'relation_patterns': 0,
            'importance_scores_calculated': 0,
            'vector_index_updated': 0
        }
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载配置文件"""
        with open(config_path, 'r', encoding='utf-8') as f:
            return toml.load(f)
    
    def _setup_logging(self) -> logging.Logger:
        """设置日志"""
        log_dir = Path(self.config['logging']['file']).parent
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=getattr(logging, self.config['logging']['level']),
            format=self.config['logging']['format'],
            handlers=[
                logging.FileHandler(self.config['logging']['file'], encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        return logging.getLogger(__name__)
    
    async def build_entity_index(self) -> None:
        """构建实体索引"""
        self.logger.info("开始构建实体索引...")
        
        # 1. 实体去重和合并
        await self._merge_duplicate_entities()
        
        # 2. 计算实体重要性分数
        await self._calculate_entity_importance()
        
        # 3. 构建实体聚类
        await self._build_entity_clusters()
        
        # 4. 生成实体向量索引
        await self._build_entity_vector_index()
        
        self.logger.info("实体索引构建完成")
    
    async def _merge_duplicate_entities(self) -> None:
        """合并重复实体"""
        self.logger.info("合并重复实体...")
        
        workspace_id = self.config['processing']['workspace_id']
        
        with self.db.conn.cursor() as cur:
            # 查找可能重复的实体（名称相似）
            cur.execute("""
                SELECT 
                    entity_name,
                    entity_type,
                    COUNT(*) as frequency,
                    array_agg(id) as entity_ids,
                    array_agg(description) as descriptions
                FROM rag_doc_chunk_entity e
                JOIN rag_doc d ON e.doc_id = d.id
                WHERE d.workspace_id = %s
                GROUP BY entity_name, entity_type
                HAVING COUNT(*) > 1
                ORDER BY COUNT(*) DESC
            """, (workspace_id,))
            
            duplicate_groups = cur.fetchall()
            
            for group in duplicate_groups:
                await self._merge_entity_group(group)
                self.index_stats['entities_processed'] += 1
        
        self.logger.info(f"处理了 {len(duplicate_groups)} 个重复实体组")
    
    async def _merge_entity_group(self, group: Tuple) -> None:
        """合并实体组"""
        entity_name, entity_type, frequency, entity_ids, descriptions = group
        
        # 合并描述
        valid_descriptions = [desc for desc in descriptions if desc and desc.strip()]
        merged_description = '<SEQ>'.join(set(valid_descriptions)) if valid_descriptions else ''
        
        # 保留第一个实体，删除其他重复项
        keep_id = entity_ids[0]
        remove_ids = entity_ids[1:]
        
        with self.db.conn.cursor() as cur:
            # 更新保留的实体描述
            cur.execute("""
                UPDATE rag_doc_chunk_entity 
                SET description = %s, update_time = %s
                WHERE id = %s
            """, (merged_description, datetime.now(), keep_id))
            
            # 删除重复实体
            if remove_ids:
                cur.execute("""
                    DELETE FROM rag_doc_chunk_entity 
                    WHERE id = ANY(%s)
                """, (remove_ids,))
    
    async def _calculate_entity_importance(self) -> None:
        """计算实体重要性分数"""
        self.logger.info("计算实体重要性分数...")
        
        workspace_id = self.config['processing']['workspace_id']
        
        with self.db.conn.cursor() as cur:
            # 获取所有实体及其统计信息
            cur.execute("""
                SELECT 
                    e.entity_name,
                    e.entity_type,
                    COUNT(DISTINCT e.doc_id) as doc_frequency,
                    COUNT(*) as total_frequency,
                    COUNT(DISTINCT e.chunk_id) as chunk_frequency
                FROM rag_doc_chunk_entity e
                JOIN rag_doc d ON e.doc_id = d.id
                WHERE d.workspace_id = %s
                GROUP BY e.entity_name, e.entity_type
            """, (workspace_id,))
            
            entities = cur.fetchall()
            
            # 计算总文档数
            cur.execute("""
                SELECT COUNT(DISTINCT id) FROM rag_doc WHERE workspace_id = %s
            """, (workspace_id,))
            total_docs = cur.fetchone()[0]
            
            # 为每个实体计算重要性分数
            for entity in entities:
                importance_score = self._compute_entity_importance(entity, total_docs)
                
                # 更新实体重要性分数（存储在description字段中）
                entity_name, entity_type = entity[0], entity[1]
                cur.execute("""
                    UPDATE rag_doc_chunk_entity 
                    SET description = COALESCE(description, '') || 
                        CASE 
                            WHEN description IS NULL OR description = '' THEN 'importance:' || %s
                            ELSE '<SEQ>importance:' || %s
                        END
                    WHERE entity_name = %s AND entity_type = %s
                """, (importance_score, importance_score, entity_name, entity_type))
                
                self.index_stats['importance_scores_calculated'] += 1
    
    def _compute_entity_importance(self, entity: Tuple, total_docs: int) -> float:
        """计算单个实体的重要性分数"""
        entity_name, entity_type, doc_frequency, total_frequency, chunk_frequency = entity
        
        # TF-IDF风格的重要性计算
        tf = total_frequency  # 词频
        df = doc_frequency    # 文档频率
        
        # 避免除零
        if df == 0 or total_docs == 0:
            return 0.0
        
        # 计算IDF
        idf = np.log(total_docs / df)
        
        # 结合其他因素
        chunk_diversity = chunk_frequency / max(total_frequency, 1)
        
        # 实体类型权重
        type_weights = {
            'PERSON': 1.2,
            'ORG': 1.5,
            'LOCATION': 1.0,
            'PRODUCT': 1.3,
            'TECHNOLOGY': 1.4,
            'EVENT': 1.1,
            'CONCEPT': 0.9
        }
        
        type_weight = type_weights.get(entity_type, 1.0)
        
        # 综合重要性分数
        importance = (tf * idf * chunk_diversity * type_weight) / 100
        
        return round(min(importance, 1.0), 4)  # 限制在0-1之间
    
    async def _build_entity_clusters(self) -> None:
        """构建实体聚类"""
        self.logger.info("构建实体聚类...")
        
        workspace_id = self.config['processing']['workspace_id']
        
        # 基于实体类型和共现关系进行聚类
        with self.db.conn.cursor() as cur:
            # 获取实体共现矩阵
            cur.execute("""
                SELECT DISTINCT
                    e1.entity_name as entity1,
                    e1.entity_type as type1,
                    e2.entity_name as entity2,
                    e2.entity_type as type2,
                    COUNT(*) as cooccurrence
                FROM rag_doc_chunk_entity e1
                JOIN rag_doc_chunk_entity e2 ON e1.chunk_id = e2.chunk_id AND e1.id != e2.id
                JOIN rag_doc d ON e1.doc_id = d.id
                WHERE d.workspace_id = %s
                GROUP BY e1.entity_name, e1.entity_type, e2.entity_name, e2.entity_type
                HAVING COUNT(*) >= 2
                ORDER BY cooccurrence DESC
            """, (workspace_id,))
            
            cooccurrences = cur.fetchall()
            
            # 简单的基于连通性的聚类
            clusters = self._perform_entity_clustering(cooccurrences)
            
            self.index_stats['entity_clusters'] = len(clusters)
            self.logger.info(f"生成了 {len(clusters)} 个实体聚类")
    
    def _perform_entity_clustering(self, cooccurrences: List[Tuple]) -> List[List[str]]:
        """执行实体聚类"""
        # 构建邻接表
        graph = defaultdict(set)
        entities = set()
        
        for cooc in cooccurrences:
            entity1 = f"{cooc[0]}:{cooc[1]}"
            entity2 = f"{cooc[2]}:{cooc[3]}"
            
            graph[entity1].add(entity2)
            graph[entity2].add(entity1)
            entities.add(entity1)
            entities.add(entity2)
        
        # 使用DFS找连通分量
        visited = set()
        clusters = []
        
        def dfs(node, cluster):
            if node in visited:
                return
            visited.add(node)
            cluster.append(node)
            for neighbor in graph[node]:
                dfs(neighbor, cluster)
        
        for entity in entities:
            if entity not in visited:
                cluster = []
                dfs(entity, cluster)
                if len(cluster) > 1:  # 只保留有多个实体的聚类
                    clusters.append(cluster)
        
        return clusters
    
    async def _build_entity_vector_index(self) -> None:
        """构建实体向量索引"""
        self.logger.info("构建实体向量索引...")
        
        workspace_id = self.config['processing']['workspace_id']
        
        with self.db.conn.cursor() as cur:
            # 获取所有唯一实体
            cur.execute("""
                SELECT DISTINCT
                    entity_name,
                    entity_type,
                    string_agg(DISTINCT description, ' ') as combined_description
                FROM rag_doc_chunk_entity e
                JOIN rag_doc d ON e.doc_id = d.id
                WHERE d.workspace_id = %s
                GROUP BY entity_name, entity_type
            """, (workspace_id,))
            
            entities = cur.fetchall()
            
            # 为每个实体生成向量
            entity_texts = []
            entity_metadatas = []
            entity_ids = []
            
            for entity in entities:
                entity_name, entity_type, combined_description = entity
                
                # 构建实体描述文本
                entity_text = f"{entity_name} ({entity_type})"
                if combined_description:
                    entity_text += f": {combined_description}"
                
                entity_texts.append(entity_text)
                entity_metadatas.append({
                    'entity_name': entity_name,
                    'entity_type': entity_type,
                    'description': combined_description or '',
                    'data_type': 'entity'
                })
                entity_ids.append(f"entity_{entity_name}_{entity_type}")
            
            # 批量生成向量
            if entity_texts:
                vectors = await self.openai_client.batch_generate_embeddings(entity_texts)
                
                # 存储到向量数据库
                self.vector_store.add_vectors(vectors, entity_metadatas, entity_ids)
                self.index_stats['vector_index_updated'] += len(vectors)
                
                self.logger.info(f"为 {len(entities)} 个实体生成了向量索引")
    
    async def build_relation_index(self) -> None:
        """构建关系索引"""
        self.logger.info("开始构建关系索引...")
        
        # 1. 关系模式识别
        await self._identify_relation_patterns()
        
        # 2. 关系权重标准化
        await self._normalize_relation_weights()
        
        # 3. 构建关系路径索引
        await self._build_relation_paths()
        
        self.logger.info("关系索引构建完成")
    
    async def _identify_relation_patterns(self) -> None:
        """识别关系模式"""
        self.logger.info("识别关系模式...")
        
        workspace_id = self.config['processing']['workspace_id']
        
        with self.db.conn.cursor() as cur:
            # 分析关系类型模式
            cur.execute("""
                SELECT 
                    keywords as relation_type,
                    COUNT(*) as frequency,
                    AVG(weight) as avg_weight,
                    array_agg(DISTINCT src_entity_name) as src_entities,
                    array_agg(DISTINCT tgt_entity_name) as tgt_entities
                FROM rag_doc_chunk_relation r
                JOIN rag_doc d ON r.doc_id = d.id
                WHERE d.workspace_id = %s
                GROUP BY keywords
                ORDER BY frequency DESC
            """, (workspace_id,))
            
            patterns = cur.fetchall()
            
            # 分析每种关系模式的特征
            for pattern in patterns:
                pattern_analysis = self._analyze_relation_pattern(pattern)
                self.logger.info(f"关系模式 '{pattern[0]}': {pattern_analysis}")
                self.index_stats['relations_processed'] += 1
            
            self.index_stats['relation_patterns'] = len(patterns)
    
    def _analyze_relation_pattern(self, pattern: Tuple) -> Dict[str, Any]:
        """分析单个关系模式"""
        relation_type, frequency, avg_weight, src_entities, tgt_entities = pattern
        
        return {
            'frequency': frequency,
            'avg_weight': round(avg_weight or 0, 3),
            'unique_sources': len(set(src_entities)),
            'unique_targets': len(set(tgt_entities)),
            'diversity_score': len(set(src_entities)) * len(set(tgt_entities)) / max(frequency, 1)
        }
    
    async def _normalize_relation_weights(self) -> None:
        """标准化关系权重"""
        self.logger.info("标准化关系权重...")
        
        workspace_id = self.config['processing']['workspace_id']
        
        with self.db.conn.cursor() as cur:
            # 获取每种关系类型的权重分布
            cur.execute("""
                SELECT 
                    keywords as relation_type,
                    MIN(weight) as min_weight,
                    MAX(weight) as max_weight,
                    AVG(weight) as avg_weight,
                    STDDEV(weight) as std_weight
                FROM rag_doc_chunk_relation r
                JOIN rag_doc d ON r.doc_id = d.id
                WHERE d.workspace_id = %s
                GROUP BY keywords
            """, (workspace_id,))
            
            weight_stats = cur.fetchall()
            
            # 为每种关系类型进行权重标准化
            for stat in weight_stats:
                relation_type, min_weight, max_weight, avg_weight, std_weight = stat
                if max_weight and min_weight and max_weight > min_weight:
                    await self._normalize_relation_type_weights(
                        relation_type, min_weight, max_weight, workspace_id
                    )
    
    async def _normalize_relation_type_weights(self, relation_type: str, 
                                            min_weight: float, max_weight: float, 
                                            workspace_id: str) -> None:
        """标准化特定关系类型的权重"""
        # Min-Max标准化到0-1范围
        with self.db.conn.cursor() as cur:
            cur.execute("""
                UPDATE rag_doc_chunk_relation 
                SET weight = CASE 
                    WHEN %s = %s THEN 0.5
                    ELSE (weight - %s) / (%s - %s)
                END
                WHERE keywords = %s
                AND doc_id IN (
                    SELECT id FROM rag_doc WHERE workspace_id = %s
                )
            """, (max_weight, min_weight, min_weight, max_weight, min_weight, 
                  relation_type, workspace_id))
    
    async def _build_relation_paths(self) -> None:
        """构建关系路径索引"""
        self.logger.info("构建关系路径索引...")
        
        workspace_id = self.config['processing']['workspace_id']
        
        with self.db.conn.cursor() as cur:
            # 查找2跳路径
            cur.execute("""
                SELECT DISTINCT
                    r1.src_entity_name as start_entity,
                    r1.tgt_entity_name as middle_entity,
                    r2.tgt_entity_name as end_entity,
                    r1.keywords as relation1,
                    r2.keywords as relation2,
                    (r1.weight + r2.weight) / 2 as path_weight
                FROM rag_doc_chunk_relation r1
                JOIN rag_doc_chunk_relation r2 ON r1.tgt_entity_name = r2.src_entity_name
                JOIN rag_doc d1 ON r1.doc_id = d1.id
                JOIN rag_doc d2 ON r2.doc_id = d2.id
                WHERE d1.workspace_id = %s AND d2.workspace_id = %s
                AND r1.src_entity_name != r2.tgt_entity_name
                ORDER BY path_weight DESC
                LIMIT 1000
            """, (workspace_id, workspace_id))
            
            paths = cur.fetchall()
            
            # 记录路径信息
            self.logger.info(f"发现 {len(paths)} 条2跳关系路径")
    
    async def build_knowledge_graph_index(self) -> None:
        """构建完整的知识图谱索引"""
        self.logger.info("开始构建知识图谱索引...")
        
        # 1. 构建实体索引
        await self.build_entity_index()
        
        # 2. 构建关系索引
        await self.build_relation_index()
        
        # 3. 计算图统计信息
        await self._calculate_graph_statistics()
        
        # 4. 生成索引摘要
        await self._generate_index_summary()
        
        self.logger.info("知识图谱索引构建完成")
    
    async def _calculate_graph_statistics(self) -> None:
        """计算图统计信息"""
        self.logger.info("计算图统计信息...")
        
        workspace_id = self.config['processing']['workspace_id']
        
        with self.db.conn.cursor() as cur:
            # 节点统计
            cur.execute("""
                SELECT 
                    COUNT(DISTINCT entity_name) as unique_entities,
                    COUNT(DISTINCT entity_type) as entity_types,
                    COUNT(*) as total_entity_mentions
                FROM rag_doc_chunk_entity e
                JOIN rag_doc d ON e.doc_id = d.id
                WHERE d.workspace_id = %s
            """, (workspace_id,))
            
            entity_stats = cur.fetchone()
            
            # 边统计
            cur.execute("""
                SELECT 
                    COUNT(DISTINCT keywords) as relation_types,
                    COUNT(*) as total_relations,
                    AVG(weight) as avg_relation_weight
                FROM rag_doc_chunk_relation r
                JOIN rag_doc d ON r.doc_id = d.id
                WHERE d.workspace_id = %s
            """, (workspace_id,))
            
            relation_stats = cur.fetchone()
            
            # 连通性统计
            cur.execute("""
                SELECT 
                    COUNT(DISTINCT src_entity_name) as entities_with_outgoing,
                    COUNT(DISTINCT tgt_entity_name) as entities_with_incoming
                FROM rag_doc_chunk_relation r
                JOIN rag_doc d ON r.doc_id = d.id
                WHERE d.workspace_id = %s
            """, (workspace_id,))
            
            connectivity_stats = cur.fetchone()
            
            # 记录统计信息
            graph_stats = {
                'entities': {
                    'unique_entities': entity_stats[0],
                    'entity_types': entity_stats[1],
                    'total_mentions': entity_stats[2]
                },
                'relations': {
                    'relation_types': relation_stats[0],
                    'total_relations': relation_stats[1],
                    'avg_weight': round(relation_stats[2] or 0, 3)
                },
                'connectivity': {
                    'entities_with_outgoing': connectivity_stats[0],
                    'entities_with_incoming': connectivity_stats[1]
                }
            }
            
            self.logger.info(f"图统计信息: {graph_stats}")
    
    async def _generate_index_summary(self) -> None:
        """生成索引摘要"""
        summary = {
            'workspace_id': self.config['processing']['workspace_id'],
            'index_build_time': datetime.now().isoformat(),
            'statistics': self.index_stats,
            'status': 'completed'
        }
        
        self.logger.info("=== 索引构建摘要 ===")
        self.logger.info(f"工作空间ID: {summary['workspace_id']}")
        self.logger.info(f"构建时间: {summary['index_build_time']}")
        for key, value in self.index_stats.items():
            self.logger.info(f"{key}: {value}")
    
    def print_index_statistics(self) -> None:
        """打印索引统计信息"""
        self.logger.info("=== 知识图谱索引统计 ===")
        for key, value in self.index_stats.items():
            self.logger.info(f"{key}: {value}")
    
    async def run(self) -> None:
        """运行完整的索引构建流程"""
        try:
            self.logger.info("开始NetOperatorQA知识图谱索引构建...")
            
            # 构建知识图谱索引
            await self.build_knowledge_graph_index()
            
            # 打印统计信息
            self.print_index_statistics()
            
            self.logger.info("知识图谱索引构建完成!")
            
        except Exception as e:
            self.logger.error(f"索引构建过程中发生错误: {e}")
            raise
        finally:
            self.db.close()


async def main():
    """主函数"""
    config_path = "config.toml"
    indexer = NetOperatorQAIndexer(config_path)
    await indexer.run()


if __name__ == "__main__":
    asyncio.run(main())