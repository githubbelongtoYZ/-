"""
独立的NetOperatorQA评估器
使用HotpotQA评估标准（F1分数等）
不依赖KAG源代码
"""

import logging
import asyncio
import toml
import json
import re
import string
from typing import List, Dict, Any, Optional, Tuple, Set
from pathlib import Path
from datetime import datetime
from collections import Counter
import numpy as np

from database import DatabaseManager
from openai_client import OpenAIClient
from vector_store import VectorStore


class NetOperatorQAEvaluator:
    """NetOperatorQA评估器，使用HotpotQA评估标准"""
    
    def __init__(self, config_path: str):
        """初始化评估器"""
        self.config = self._load_config(config_path)
        self.logger = self._setup_logging()
        
        # 初始化组件
        self.db = DatabaseManager(self.config)
        self.openai_client = OpenAIClient(self.config)
        self.vector_store = VectorStore(self.config)
        
        # 评估结果
        self.evaluation_results = {
            'exact_match_scores': [],
            'f1_scores': [],
            'precision_scores': [],
            'recall_scores': [],
            'retrieval_accuracy': [],
            'answer_quality': [],
            'response_times': [],
            'total_questions': 0,
            'successful_answers': 0
        }
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载配置文件"""
        with open(config_path, 'r', encoding='utf-8') as f:
            return toml.load(f)
    
    def _setup_logging(self) -> logging.Logger:
        """设置日志"""
        log_dir = Path(self.config['logging']['file']).parent
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=getattr(logging, self.config['logging']['level']),
            format=self.config['logging']['format'],
            handlers=[
                logging.FileHandler(self.config['logging']['file'], encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        return logging.getLogger(__name__)
    
    def normalize_answer(self, text: str) -> str:
        """标准化答案文本（参考HotpotQA）"""
        def remove_articles(text):
            return re.sub(r'\b(a|an|the)\b', ' ', text)
        
        def white_space_fix(text):
            return ' '.join(text.split())
        
        def remove_punc(text):
            exclude = set(string.punctuation)
            return ''.join(ch for ch in text if ch not in exclude)
        
        def lower(text):
            return text.lower()
        
        return white_space_fix(remove_articles(remove_punc(lower(text))))
    
    def compute_exact_match(self, prediction: str, ground_truth: str) -> float:
        """计算精确匹配分数（参考HotpotQA）"""
        return float(self.normalize_answer(prediction) == self.normalize_answer(ground_truth))
    
    def compute_f1_score(self, prediction: str, ground_truth: str) -> float:
        """计算F1分数（参考HotpotQA）"""
        pred_tokens = self.normalize_answer(prediction).split()
        truth_tokens = self.normalize_answer(ground_truth).split()
        
        if len(pred_tokens) == 0 and len(truth_tokens) == 0:
            return 1.0
        if len(pred_tokens) == 0 or len(truth_tokens) == 0:
            return 0.0
        
        common_tokens = Counter(pred_tokens) & Counter(truth_tokens)
        num_common = sum(common_tokens.values())
        
        if num_common == 0:
            return 0.0
        
        precision = num_common / len(pred_tokens)
        recall = num_common / len(truth_tokens)
        f1 = (2 * precision * recall) / (precision + recall)
        
        return f1
    
    def compute_precision_recall(self, prediction: str, ground_truth: str) -> Tuple[float, float]:
        """计算精确率和召回率"""
        pred_tokens = self.normalize_answer(prediction).split()
        truth_tokens = self.normalize_answer(ground_truth).split()
        
        if len(pred_tokens) == 0 and len(truth_tokens) == 0:
            return 1.0, 1.0
        if len(pred_tokens) == 0:
            return 0.0, 0.0 if len(truth_tokens) == 0 else 0.0
        if len(truth_tokens) == 0:
            return 0.0, 0.0
        
        common_tokens = Counter(pred_tokens) & Counter(truth_tokens)
        num_common = sum(common_tokens.values())
        
        precision = num_common / len(pred_tokens) if len(pred_tokens) > 0 else 0.0
        recall = num_common / len(truth_tokens) if len(truth_tokens) > 0 else 0.0
        
        return precision, recall
    
    async def retrieve_relevant_chunks(self, question: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """检索相关文档块"""
        start_time = datetime.now()
        
        # 1. 向量检索
        question_vector = await self.openai_client.generate_embedding(question)
        vector_results = self.vector_store.search_similar(question_vector, top_k=top_k*2)
        
        # 2. 关键词检索
        workspace_id = self.config['processing']['workspace_id']
        keywords = self._extract_keywords(question)
        
        keyword_results = []
        if keywords:
            with self.db.conn.cursor() as cur:
                keyword_query = ' | '.join(keywords)
                cur.execute("""
                    SELECT DISTINCT
                        c.id,
                        c.content,
                        d.title,
                        ts_rank(to_tsvector('english', c.content), plainto_tsquery('english', %s)) as rank
                    FROM rag_doc_chunk c
                    JOIN rag_doc d ON c.doc_id = d.id
                    WHERE d.workspace_id = %s
                    AND to_tsvector('english', c.content) @@ plainto_tsquery('english', %s)
                    ORDER BY rank DESC
                    LIMIT %s
                """, (keyword_query, workspace_id, keyword_query, top_k))
                
                keyword_results = cur.fetchall()
        
        # 3. 实体检索
        entities = await self._extract_entities_from_question(question)
        entity_results = []
        
        if entities:
            with self.db.conn.cursor() as cur:
                entity_names = [e['name'] for e in entities]
                cur.execute("""
                    SELECT DISTINCT
                        c.id,
                        c.content,
                        d.title,
                        COUNT(e.entity_name) as entity_match_count
                    FROM rag_doc_chunk c
                    JOIN rag_doc d ON c.doc_id = d.id
                    JOIN rag_doc_chunk_entity e ON c.id = e.chunk_id
                    WHERE d.workspace_id = %s
                    AND e.entity_name = ANY(%s)
                    GROUP BY c.id, c.content, d.title
                    ORDER BY entity_match_count DESC
                    LIMIT %s
                """, (workspace_id, entity_names, top_k))
                
                entity_results = cur.fetchall()
        
        # 4. 合并和排序结果
        all_results = self._merge_retrieval_results(vector_results, keyword_results, entity_results)
        
        retrieval_time = (datetime.now() - start_time).total_seconds()
        
        return all_results[:top_k], retrieval_time
    
    def _extract_keywords(self, text: str) -> List[str]:
        """提取关键词"""
        # 简单的关键词提取
        stop_words = {'的', '是', '在', '有', '和', '与', '或', '但', '如果', '因为', '所以', '什么', '怎么', '为什么', '哪里', '何时'}
        words = re.findall(r'\b\w+\b', text.lower())
        keywords = [word for word in words if len(word) > 1 and word not in stop_words]
        return keywords[:10]  # 限制关键词数量
    
    async def _extract_entities_from_question(self, question: str) -> List[Dict[str, Any]]:
        """从问题中提取实体"""
        prompt = f"""
        从以下问题中提取实体，返回JSON格式：
        
        问题：{question}
        
        请提取人名、组织名、地名、产品名、技术名等实体。
        
        返回格式：
        {{
            "entities": [
                {{
                    "name": "实体名称",
                    "type": "实体类型"
                }}
            ]
        }}
        """
        
        try:
            response = await self.openai_client.generate_text(prompt)
            result = json.loads(response)
            return result.get('entities', [])
        except Exception as e:
            self.logger.error(f"实体提取失败: {e}")
            return []
    
    def _merge_retrieval_results(self, vector_results: List, keyword_results: List, entity_results: List) -> List[Dict[str, Any]]:
        """合并检索结果"""
        result_map = {}
        
        # 处理向量检索结果
        for i, result in enumerate(vector_results):
            chunk_id = result['metadata'].get('chunk_id')
            if chunk_id:
                result_map[chunk_id] = {
                    'chunk_id': chunk_id,
                    'content': result['metadata'].get('text', ''),
                    'title': result['metadata'].get('title', ''),
                    'vector_score': result['score'],
                    'vector_rank': i + 1,
                    'keyword_score': 0,
                    'entity_score': 0
                }
        
        # 处理关键词检索结果
        for i, result in enumerate(keyword_results):
            chunk_id = result[0]
            if chunk_id in result_map:
                result_map[chunk_id]['keyword_score'] = result[3]  # rank
                result_map[chunk_id]['keyword_rank'] = i + 1
            else:
                result_map[chunk_id] = {
                    'chunk_id': chunk_id,
                    'content': result[1],
                    'title': result[2],
                    'vector_score': 0,
                    'keyword_score': result[3],
                    'keyword_rank': i + 1,
                    'entity_score': 0
                }
        
        # 处理实体检索结果
        for i, result in enumerate(entity_results):
            chunk_id = result[0]
            if chunk_id in result_map:
                result_map[chunk_id]['entity_score'] = result[3]  # entity_match_count
                result_map[chunk_id]['entity_rank'] = i + 1
            else:
                result_map[chunk_id] = {
                    'chunk_id': chunk_id,
                    'content': result[1],
                    'title': result[2],
                    'vector_score': 0,
                    'keyword_score': 0,
                    'entity_score': result[3],
                    'entity_rank': i + 1
                }
        
        # 计算综合分数并排序
        for chunk_id, data in result_map.items():
            # 综合分数计算
            vector_score = data['vector_score'] * 0.4
            keyword_score = data['keyword_score'] * 0.3
            entity_score = data['entity_score'] * 0.3
            
            data['combined_score'] = vector_score + keyword_score + entity_score
        
        # 按综合分数排序
        sorted_results = sorted(result_map.values(), key=lambda x: x['combined_score'], reverse=True)
        
        return sorted_results
    
    async def generate_answer(self, question: str, relevant_chunks: List[Dict[str, Any]]) -> str:
        """基于检索到的文档块生成答案"""
        if not relevant_chunks:
            return "抱歉，我无法找到相关信息来回答这个问题。"
        
        # 构建上下文
        context_parts = []
        for i, chunk in enumerate(relevant_chunks[:3]):  # 使用前3个最相关的块
            context_parts.append(f"文档{i+1}：{chunk['content'][:500]}")
        
        context = "\n\n".join(context_parts)
        
        # 生成答案的提示词
        prompt = f"""
        基于以下文档内容回答问题。请提供准确、简洁的答案。
        
        问题：{question}
        
        相关文档：
        {context}
        
        请基于上述文档内容回答问题。如果文档中没有足够信息，请说明无法确定答案。
        
        答案：
        """
        
        try:
            answer = await self.openai_client.generate_text(prompt)
            return answer.strip()
        except Exception as e:
            self.logger.error(f"答案生成失败: {e}")
            return "抱歉，生成答案时发生错误。"
    
    async def evaluate_single_qa(self, question: str, ground_truth: str) -> Dict[str, Any]:
        """评估单个问答对"""
        start_time = datetime.now()
        
        try:
            # 1. 检索相关文档
            relevant_chunks, retrieval_time = await self.retrieve_relevant_chunks(question)
            
            # 2. 生成答案
            predicted_answer = await self.generate_answer(question, relevant_chunks)
            
            # 3. 计算评估指标
            exact_match = self.compute_exact_match(predicted_answer, ground_truth)
            f1_score = self.compute_f1_score(predicted_answer, ground_truth)
            precision, recall = self.compute_precision_recall(predicted_answer, ground_truth)
            
            # 4. 评估检索质量
            retrieval_accuracy = self._evaluate_retrieval_quality(question, ground_truth, relevant_chunks)
            
            # 5. 评估答案质量
            answer_quality = await self._evaluate_answer_quality(question, predicted_answer, ground_truth)
            
            total_time = (datetime.now() - start_time).total_seconds()
            
            result = {
                'question': question,
                'ground_truth': ground_truth,
                'predicted_answer': predicted_answer,
                'exact_match': exact_match,
                'f1_score': f1_score,
                'precision': precision,
                'recall': recall,
                'retrieval_accuracy': retrieval_accuracy,
                'answer_quality': answer_quality,
                'response_time': total_time,
                'retrieval_time': retrieval_time,
                'relevant_chunks_count': len(relevant_chunks),
                'success': True
            }
            
            return result
            
        except Exception as e:
            self.logger.error(f"评估问答对失败: {e}")
            return {
                'question': question,
                'ground_truth': ground_truth,
                'predicted_answer': '',
                'exact_match': 0.0,
                'f1_score': 0.0,
                'precision': 0.0,
                'recall': 0.0,
                'retrieval_accuracy': 0.0,
                'answer_quality': 0.0,
                'response_time': 0.0,
                'retrieval_time': 0.0,
                'relevant_chunks_count': 0,
                'success': False,
                'error': str(e)
            }
    
    def _evaluate_retrieval_quality(self, question: str, ground_truth: str, relevant_chunks: List[Dict[str, Any]]) -> float:
        """评估检索质量"""
        if not relevant_chunks:
            return 0.0
        
        # 简单的检索质量评估：检查检索到的文档是否包含答案中的关键信息
        truth_tokens = set(self.normalize_answer(ground_truth).split())
        
        total_overlap = 0
        for chunk in relevant_chunks:
            chunk_tokens = set(self.normalize_answer(chunk['content']).split())
            overlap = len(truth_tokens & chunk_tokens)
            total_overlap += overlap
        
        if len(truth_tokens) == 0:
            return 1.0
        
        # 计算平均重叠度
        max_possible_overlap = len(truth_tokens) * len(relevant_chunks)
        if max_possible_overlap == 0:
            return 0.0
        
        return min(total_overlap / max_possible_overlap, 1.0)
    
    async def _evaluate_answer_quality(self, question: str, predicted_answer: str, ground_truth: str) -> float:
        """评估答案质量"""
        prompt = f"""
        请评估以下答案的质量，给出0-1之间的分数。
        
        问题：{question}
        
        标准答案：{ground_truth}
        
        预测答案：{predicted_answer}
        
        评估标准：
        1. 准确性：答案是否正确
        2. 完整性：答案是否完整
        3. 相关性：答案是否与问题相关
        4. 清晰度：答案是否清晰易懂
        
        请只返回一个0-1之间的数字分数。
        """
        
        try:
            response = await self.openai_client.generate_text(prompt)
            score = float(re.search(r'0\.\d+|1\.0|0|1', response).group())
            return max(0.0, min(1.0, score))
        except Exception as e:
            self.logger.error(f"答案质量评估失败: {e}")
            # 回退到基于F1分数的质量评估
            return self.compute_f1_score(predicted_answer, ground_truth)
    
    async def load_qa_dataset(self) -> List[Dict[str, str]]:
        """加载问答数据集"""
        dataset_path = Path(self.config['dataset']['qa_pairs_path'])
        
        if not dataset_path.exists():
            self.logger.error(f"问答数据集文件不存在: {dataset_path}")
            return []
        
        try:
            with open(dataset_path, 'r', encoding='utf-8') as f:
                qa_data = json.load(f)
            
            # 标准化数据格式
            qa_pairs = []
            for item in qa_data:
                if isinstance(item, dict) and 'question' in item and 'answer' in item:
                    qa_pairs.append({
                        'question': item['question'],
                        'answer': item['answer']
                    })
            
            self.logger.info(f"加载了 {len(qa_pairs)} 个问答对")
            return qa_pairs
            
        except Exception as e:
            self.logger.error(f"加载问答数据集失败: {e}")
            return []
    
    async def evaluate_dataset(self, sample_size: Optional[int] = None) -> Dict[str, Any]:
        """评估整个数据集"""
        self.logger.info("开始评估NetOperatorQA数据集...")
        
        # 加载问答数据集
        qa_pairs = await self.load_qa_dataset()
        
        if not qa_pairs:
            self.logger.error("没有找到有效的问答对")
            return {}
        
        # 如果指定了样本大小，随机采样
        if sample_size and sample_size < len(qa_pairs):
            import random
            qa_pairs = random.sample(qa_pairs, sample_size)
            self.logger.info(f"随机采样 {sample_size} 个问答对进行评估")
        
        # 评估每个问答对
        results = []
        for i, qa_pair in enumerate(qa_pairs):
            self.logger.info(f"评估进度: {i+1}/{len(qa_pairs)}")
            
            result = await self.evaluate_single_qa(qa_pair['question'], qa_pair['answer'])
            results.append(result)
            
            # 更新统计信息
            if result['success']:
                self.evaluation_results['exact_match_scores'].append(result['exact_match'])
                self.evaluation_results['f1_scores'].append(result['f1_score'])
                self.evaluation_results['precision_scores'].append(result['precision'])
                self.evaluation_results['recall_scores'].append(result['recall'])
                self.evaluation_results['retrieval_accuracy'].append(result['retrieval_accuracy'])
                self.evaluation_results['answer_quality'].append(result['answer_quality'])
                self.evaluation_results['response_times'].append(result['response_time'])
                self.evaluation_results['successful_answers'] += 1
            
            self.evaluation_results['total_questions'] += 1
        
        # 计算总体统计
        overall_stats = self._calculate_overall_statistics()
        
        # 保存详细结果
        await self._save_evaluation_results(results, overall_stats)
        
        return overall_stats
    
    def _calculate_overall_statistics(self) -> Dict[str, Any]:
        """计算总体统计信息"""
        if not self.evaluation_results['f1_scores']:
            return {'error': '没有成功的评估结果'}
        
        stats = {
            'total_questions': self.evaluation_results['total_questions'],
            'successful_answers': self.evaluation_results['successful_answers'],
            'success_rate': self.evaluation_results['successful_answers'] / self.evaluation_results['total_questions'],
            
            # 主要指标
            'exact_match': {
                'mean': np.mean(self.evaluation_results['exact_match_scores']),
                'std': np.std(self.evaluation_results['exact_match_scores']),
                'min': np.min(self.evaluation_results['exact_match_scores']),
                'max': np.max(self.evaluation_results['exact_match_scores'])
            },
            
            'f1_score': {
                'mean': np.mean(self.evaluation_results['f1_scores']),
                'std': np.std(self.evaluation_results['f1_scores']),
                'min': np.min(self.evaluation_results['f1_scores']),
                'max': np.max(self.evaluation_results['f1_scores'])
            },
            
            'precision': {
                'mean': np.mean(self.evaluation_results['precision_scores']),
                'std': np.std(self.evaluation_results['precision_scores']),
                'min': np.min(self.evaluation_results['precision_scores']),
                'max': np.max(self.evaluation_results['precision_scores'])
            },
            
            'recall': {
                'mean': np.mean(self.evaluation_results['recall_scores']),
                'std': np.std(self.evaluation_results['recall_scores']),
                'min': np.min(self.evaluation_results['recall_scores']),
                'max': np.max(self.evaluation_results['recall_scores'])
            },
            
            # 检索和答案质量
            'retrieval_accuracy': {
                'mean': np.mean(self.evaluation_results['retrieval_accuracy']),
                'std': np.std(self.evaluation_results['retrieval_accuracy'])
            },
            
            'answer_quality': {
                'mean': np.mean(self.evaluation_results['answer_quality']),
                'std': np.std(self.evaluation_results['answer_quality'])
            },
            
            # 性能指标
            'response_time': {
                'mean': np.mean(self.evaluation_results['response_times']),
                'std': np.std(self.evaluation_results['response_times']),
                'min': np.min(self.evaluation_results['response_times']),
                'max': np.max(self.evaluation_results['response_times'])
            }
        }
        
        return stats
    
    async def _save_evaluation_results(self, results: List[Dict[str, Any]], overall_stats: Dict[str, Any]) -> None:
        """保存评估结果"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # 保存详细结果
        results_file = f"evaluation_results_{timestamp}.json"
        with open(results_file, 'w', encoding='utf-8') as f:
            json.dump({
                'timestamp': timestamp,
                'overall_statistics': overall_stats,
                'detailed_results': results
            }, f, ensure_ascii=False, indent=2)
        
        self.logger.info(f"评估结果已保存到: {results_file}")
        
        # 保存统计摘要
        stats_file = f"evaluation_summary_{timestamp}.txt"
        with open(stats_file, 'w', encoding='utf-8') as f:
            f.write("=== NetOperatorQA评估摘要 ===\n\n")
            f.write(f"评估时间: {timestamp}\n")
            f.write(f"总问题数: {overall_stats['total_questions']}\n")
            f.write(f"成功回答数: {overall_stats['successful_answers']}\n")
            f.write(f"成功率: {overall_stats['success_rate']:.3f}\n\n")
            
            f.write("=== 主要指标 ===\n")
            f.write(f"精确匹配 (EM): {overall_stats['exact_match']['mean']:.3f} ± {overall_stats['exact_match']['std']:.3f}\n")
            f.write(f"F1分数: {overall_stats['f1_score']['mean']:.3f} ± {overall_stats['f1_score']['std']:.3f}\n")
            f.write(f"精确率: {overall_stats['precision']['mean']:.3f} ± {overall_stats['precision']['std']:.3f}\n")
            f.write(f"召回率: {overall_stats['recall']['mean']:.3f} ± {overall_stats['recall']['std']:.3f}\n\n")
            
            f.write("=== 质量指标 ===\n")
            f.write(f"检索准确率: {overall_stats['retrieval_accuracy']['mean']:.3f} ± {overall_stats['retrieval_accuracy']['std']:.3f}\n")
            f.write(f"答案质量: {overall_stats['answer_quality']['mean']:.3f} ± {overall_stats['answer_quality']['std']:.3f}\n\n")
            
            f.write("=== 性能指标 ===\n")
            f.write(f"平均响应时间: {overall_stats['response_time']['mean']:.3f}s ± {overall_stats['response_time']['std']:.3f}s\n")
        
        self.logger.info(f"评估摘要已保存到: {stats_file}")
    
    def print_evaluation_summary(self) -> None:
        """打印评估摘要"""
        if not self.evaluation_results['f1_scores']:
            self.logger.info("没有评估结果可显示")
            return
        
        stats = self._calculate_overall_statistics()
        
        self.logger.info("=== NetOperatorQA评估摘要 ===")
        self.logger.info(f"总问题数: {stats['total_questions']}")
        self.logger.info(f"成功回答数: {stats['successful_answers']}")
        self.logger.info(f"成功率: {stats['success_rate']:.3f}")
        self.logger.info("")
        
        self.logger.info("=== 主要指标 ===")
        self.logger.info(f"精确匹配 (EM): {stats['exact_match']['mean']:.3f} ± {stats['exact_match']['std']:.3f}")
        self.logger.info(f"F1分数: {stats['f1_score']['mean']:.3f} ± {stats['f1_score']['std']:.3f}")
        self.logger.info(f"精确率: {stats['precision']['mean']:.3f} ± {stats['precision']['std']:.3f}")
        self.logger.info(f"召回率: {stats['recall']['mean']:.3f} ± {stats['recall']['std']:.3f}")
        self.logger.info("")
        
        self.logger.info("=== 质量指标 ===")
        self.logger.info(f"检索准确率: {stats['retrieval_accuracy']['mean']:.3f}")
        self.logger.info(f"答案质量: {stats['answer_quality']['mean']:.3f}")
        self.logger.info("")
        
        self.logger.info("=== 性能指标 ===")
        self.logger.info(f"平均响应时间: {stats['response_time']['mean']:.3f}s")
    
    async def run_evaluation(self, sample_size: Optional[int] = None) -> None:
        """运行完整的评估流程"""
        try:
            self.logger.info("开始NetOperatorQA评估...")
            
            # 运行评估
            overall_stats = await self.evaluate_dataset(sample_size)
            
            if overall_stats:
                # 打印摘要
                self.print_evaluation_summary()
                
                self.logger.info("评估完成!")
            else:
                self.logger.error("评估失败，没有生成统计结果")
                
        except Exception as e:
            self.logger.error(f"评估过程中发生错误: {e}")
            raise
        finally:
            self.db.close()


async def main():
    """主函数"""
    config_path = "config.toml"
    evaluator = NetOperatorQAEvaluator(config_path)
    
    # 运行评估（可以指定样本大小进行快速测试）
    await evaluator.run_evaluation(sample_size=50)  # 评估50个样本


if __name__ == "__main__":
    asyncio.run(main())
