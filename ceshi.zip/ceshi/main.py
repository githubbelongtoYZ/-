"""
NetOperatorQA独立项目主入口
整合数据处理、索引构建和评估功能
"""

import asyncio
import sys
from pathlib import Path
import toml

from processor import NetOperatorQAProcessor
from indexer import NetOperatorQAIndexer
from evaluator import NetOperatorQAEvaluator


class NetOperatorQAManager:
    """NetOperatorQA项目管理器"""
    
    def __init__(self, config_path: str = "config.toml"):
        self.config_path = config_path
        self.config = self._load_config()
    
    def _load_config(self):
        """加载配置文件"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return toml.load(f)
        except FileNotFoundError:
            print(f"配置文件 {self.config_path} 不存在！")
            sys.exit(1)
        except Exception as e:
            print(f"加载配置文件失败: {e}")
            sys.exit(1)
    
    def show_menu(self):
        """显示主菜单"""
        print("\n" + "="*50)
        print("NetOperatorQA 独立项目管理系统")
        print("="*50)
        print("1. 数据处理 - 处理MD文档和问答对")
        print("2. 索引构建 - 构建知识图谱索引")
        print("3. 评估测试 - 运行HotpotQA风格评估")
        print("4. 完整流程 - 依次执行处理、索引、评估")
        print("5. 测试连接 - 测试数据库和API连接")
        print("6. 查看配置 - 显示当前配置信息")
        print("0. 退出")
        print("="*50)
    
    async def run_processor(self):
        """运行数据处理器"""
        print("\n开始数据处理...")
        try:
            processor = NetOperatorQAProcessor(self.config_path)
            await processor.run()
            print("✅ 数据处理完成！")
        except Exception as e:
            print(f"❌ 数据处理失败: {e}")
    
    async def run_indexer(self):
        """运行索引构建器"""
        print("\n开始索引构建...")
        try:
            indexer = NetOperatorQAIndexer(self.config_path)
            await indexer.run()
            print("✅ 索引构建完成！")
        except Exception as e:
            print(f"❌ 索引构建失败: {e}")
    
    async def run_evaluator(self):
        """运行评估器"""
        print("\n开始评估测试...")
        try:
            # 询问样本大小
            sample_input = input("请输入评估样本数量（直接回车使用全部数据）: ").strip()
            sample_size = None
            if sample_input:
                try:
                    sample_size = int(sample_input)
                except ValueError:
                    print("输入无效，使用全部数据进行评估")
            
            evaluator = NetOperatorQAEvaluator(self.config_path)
            await evaluator.run_evaluation(sample_size)
            print("✅ 评估测试完成！")
        except Exception as e:
            print(f"❌ 评估测试失败: {e}")
    
    async def run_full_pipeline(self):
        """运行完整流程"""
        print("\n开始完整流程...")
        try:
            # 1. 数据处理
            print("\n步骤 1/3: 数据处理")
            await self.run_processor()
            
            # 2. 索引构建
            print("\n步骤 2/3: 索引构建")
            await self.run_indexer()
            
            # 3. 评估测试
            print("\n步骤 3/3: 评估测试")
            await self.run_evaluator()
            
            print("\n✅ 完整流程执行完成！")
        except Exception as e:
            print(f"❌ 完整流程执行失败: {e}")
    
    async def test_connections(self):
        """测试连接"""
        print("\n测试数据库和API连接...")
        try:
            from database import DatabaseManager
            from openai_client import OpenAIClient
            from vector_store import VectorStore
            
            # 测试数据库连接
            print("测试PostgreSQL连接...")
            db = DatabaseManager(self.config)
            with db.conn.cursor() as cur:
                cur.execute("SELECT version()")
                version = cur.fetchone()[0]
                print(f"✅ PostgreSQL连接成功: {version}")
            db.close()
            
            # 测试OpenAI API
            print("测试OpenAI API连接...")
            openai_client = OpenAIClient(self.config)
            test_response = await openai_client.generate_text("测试连接")
            print(f"✅ OpenAI API连接成功: {test_response[:50]}...")
            
            # 测试Qdrant连接
            print("测试Qdrant连接...")
            vector_store = VectorStore(self.config)
            collections = vector_store.client.get_collections()
            print(f"✅ Qdrant连接成功，集合数量: {len(collections.collections)}")
            
            print("\n✅ 所有连接测试通过！")
            
        except Exception as e:
            print(f"❌ 连接测试失败: {e}")
    
    def show_config(self):
        """显示配置信息"""
        print("\n当前配置信息:")
        print("="*40)
        
        # 数据库配置
        db_config = self.config.get('database', {})
        print(f"PostgreSQL: {db_config.get('host', 'N/A')}:{db_config.get('port', 'N/A')}")
        print(f"数据库名: {db_config.get('database', 'N/A')}")
        
        # Qdrant配置
        qdrant_config = self.config.get('qdrant', {})
        print(f"Qdrant: {qdrant_config.get('host', 'N/A')}:{qdrant_config.get('port', 'N/A')}")
        
        # OpenAI配置
        openai_config = self.config.get('openai', {})
        print(f"OpenAI API: {openai_config.get('base_url', 'N/A')}")
        print(f"LLM模型: {openai_config.get('llm_model', 'N/A')}")
        print(f"嵌入模型: {openai_config.get('embedding_model', 'N/A')}")
        
        # 数据集配置
        dataset_config = self.config.get('dataset', {})
        print(f"文档路径: {dataset_config.get('documents_path', 'N/A')}")
        print(f"问答路径: {dataset_config.get('qa_pairs_path', 'N/A')}")
        
        # 处理配置
        processing_config = self.config.get('processing', {})
        print(f"工作空间ID: {processing_config.get('workspace_id', 'N/A')}")
        
        print("="*40)
    
    async def run(self):
        """运行主程序"""
        while True:
            try:
                self.show_menu()
                choice = input("\n请选择操作 (0-6): ").strip()
                
                if choice == '0':
                    print("退出程序")
                    break
                elif choice == '1':
                    await self.run_processor()
                elif choice == '2':
                    await self.run_indexer()
                elif choice == '3':
                    await self.run_evaluator()
                elif choice == '4':
                    await self.run_full_pipeline()
                elif choice == '5':
                    await self.test_connections()
                elif choice == '6':
                    self.show_config()
                else:
                    print("无效选择，请重新输入")
                
                input("\n按回车键继续...")
                
            except KeyboardInterrupt:
                print("\n\n程序被用户中断")
                break
            except Exception as e:
                print(f"\n程序运行出错: {e}")
                input("按回车键继续...")


async def main():
    """主函数"""
    print("NetOperatorQA 独立项目")
    print("适用于PostgreSQL + Qdrant + OpenAI环境")
    
    # 检查配置文件
    config_path = "config.toml"
    if not Path(config_path).exists():
        print(f"\n❌ 配置文件 {config_path} 不存在！")
        print("请先创建配置文件，参考 config.toml.example")
        return
    
    # 启动管理器
    manager = NetOperatorQAManager(config_path)
    await manager.run()


if __name__ == "__main__":
    asyncio.run(main())