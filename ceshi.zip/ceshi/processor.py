"""
独立的NetOperatorQA数据处理器
不依赖KAG源代码
"""

import os
import json
import logging
import asyncio
import toml
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
from datetime import datetime
import re

from database import DatabaseManager
from openai_client import OpenAIClient
from vector_store import VectorStore


class NetOperatorQAProcessor:
    """NetOperatorQA数据处理器"""
    
    def __init__(self, config_path: str):
        """初始化处理器"""
        self.config = self._load_config(config_path)
        self.logger = self._setup_logging()
        
        # 初始化组件
        self.db = DatabaseManager(self.config)
        self.openai_client = OpenAIClient(self.config)
        self.vector_store = VectorStore(self.config)
        
        # 统计信息
        self.stats = {
            'documents_processed': 0,
            'chunks_created': 0,
            'entities_extracted': 0,
            'relations_extracted': 0,
            'vectors_created': 0
        }
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载配置文件"""
        with open(config_path, 'r', encoding='utf-8') as f:
            return toml.load(f)
    
    def _setup_logging(self) -> logging.Logger:
        """设置日志"""
        log_dir = Path(self.config['logging']['file']).parent
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=getattr(logging, self.config['logging']['level']),
            format=self.config['logging']['format'],
            handlers=[
                logging.FileHandler(self.config['logging']['file'], encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        return logging.getLogger(__name__)
    
    async def process_documents(self) -> None:
        """处理文档数据"""
        self.logger.info("开始处理文档数据...")
        
        documents_path = Path(self.config['dataset']['documents_path'])
        if not documents_path.exists():
            raise FileNotFoundError(f"文档路径不存在: {documents_path}")
        
        # 初始化工作空间
        self.db.init_workspace()
        
        # 获取所有MD文件
        md_files = list(documents_path.glob("*.md"))
        self.logger.info(f"找到 {len(md_files)} 个MD文件")
        
        for md_file in md_files:
            try:
                await self._process_single_document(md_file)
                self.stats['documents_processed'] += 1
                self.logger.info(f"已处理文档: {md_file.name} ({self.stats['documents_processed']}/{len(md_files)})")
            except Exception as e:
                self.logger.error(f"处理文档失败 {md_file.name}: {e}")
        
        # 更新工作空间文档数量
        self.db.update_workspace_doc_count()
        
        self.logger.info("文档处理完成")
    
    async def _process_single_document(self, file_path: Path) -> None:
        """处理单个文档"""
        # 读取文档内容
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 解析文档元数据
        doc_series, doc_type = self._parse_document_metadata(file_path.name, content)
        
        # 构建元数据
        meta = {
            "document_series": doc_series,
            "document_type": doc_type,
            "source_dataset": "NetOperatorQA",
            "file_path": str(file_path)
        }
        
        # 插入文档记录
        doc_id = self.db.insert_document(file_path.name, content, meta)
        
        # 文档分块
        chunks = self._chunk_document(content)
        
        # 处理每个块
        chunk_data = []
        for i, chunk in enumerate(chunks):
            chunk_id = await self._process_chunk(doc_id, chunk, i)
            chunk_data.append({
                'id': chunk_id,
                'content': chunk['text'],
                'doc_name': file_path.name,
                'chunk_index': i
            })
        
        # 批量生成向量并存储到Qdrant
        await self._store_chunk_vectors(chunk_data)
        
        # 计算实体度信息
        self.db.calculate_entity_degrees(doc_id)
        
        # 更新文档状态
        self.db.update_document_status(doc_id, 2, len(chunks))  # status=2表示处理完成
        
        self.logger.info(f"文档 {file_path.name} 处理完成: {len(chunks)} 个块")
    
    def _parse_document_metadata(self, filename: str, content: str) -> Tuple[str, str]:
        """解析文档元数据"""
        # 从文件名提取系列
        series_match = re.match(r'^([A-Z]{2})', filename)
        doc_series = series_match.group(1) if series_match else 'UNKNOWN'
        
        # 从内容推断文档类型
        doc_type = "其他"
        if "新闻" in content or "报道" in content:
            doc_type = "新闻报道"
        elif "党建" in content or "教育" in content:
            doc_type = "党建教育"
        elif "运维" in content or "网络" in content:
            doc_type = "网络运维"
        elif "年度" in content or "报告" in content:
            doc_type = "年度报告"
        
        return doc_series, doc_type
    
    def _chunk_document(self, content: str) -> List[Dict[str, Any]]:
        """文档分块"""
        chunk_size = self.config['processing']['chunk_size']
        overlap = self.config['processing']['chunk_overlap']
        min_chunk_size = self.config['processing']['min_chunk_size']
        
        chunks = []
        start = 0
        chunk_order = 0
        
        while start < len(content):
            end = start + chunk_size
            chunk_text = content[start:end]
            
            # 确保不在单词中间切断
            if end < len(content) and not content[end].isspace():
                last_space = chunk_text.rfind(' ')
                if last_space > min_chunk_size:
                    chunk_text = chunk_text[:last_space]
                    end = start + last_space
            
            if len(chunk_text.strip()) >= min_chunk_size:
                chunks.append({
                    'text': chunk_text.strip(),
                    'order': chunk_order,
                    'start_pos': start,
                    'end_pos': end
                })
                chunk_order += 1
            
            start = end - overlap
            if start >= len(content):
                break
        
        return chunks
    
    async def _process_chunk(self, doc_id: str, chunk: Dict[str, Any], chunk_index: int) -> str:
        """处理文档块"""
        # 插入块记录
        chunk_id = self.db.insert_chunk(doc_id, chunk['text'], chunk['order'])
        
        # 提取实体
        entities = await self.openai_client.extract_entities(
            chunk['text'], 
            self.config['indexing']['entity_types']
        )
        
        # 存储实体
        for entity in entities[:self.config['indexing']['max_entities_per_chunk']]:
            self.db.insert_entity(
                doc_id, chunk_id, 
                entity['name'], entity['type'], 
                entity.get('description', '')
            )
            self.stats['entities_extracted'] += 1
        
        # 提取关系
        if len(entities) >= 2:
            relations = await self.openai_client.extract_relations(
                chunk['text'], entities, 
                self.config['indexing']['relation_types']
            )
            
            # 存储关系
            for relation in relations[:self.config['indexing']['max_relations_per_chunk']]:
                self.db.insert_relation(
                    doc_id, chunk_id,
                    relation['subject'], relation['object'],
                    relation['relation'], 
                    relation.get('confidence', 0.0),
                    relation.get('description', '')
                )
                self.stats['relations_extracted'] += 1
        
        self.stats['chunks_created'] += 1
        return chunk_id
    
    async def _store_chunk_vectors(self, chunk_data: List[Dict[str, Any]]) -> None:
        """存储块向量到Qdrant"""
        if not chunk_data:
            return
        
        # 批量生成向量
        texts = [chunk['content'] for chunk in chunk_data]
        vectors = await self.openai_client.batch_generate_embeddings(texts)
        
        # 准备元数据
        metadatas = []
        ids = []
        for chunk, vector in zip(chunk_data, vectors):
            metadatas.append({
                'chunk_id': chunk['id'],
                'doc_name': chunk['doc_name'],
                'chunk_index': chunk['chunk_index'],
                'content_preview': chunk['content'][:200]  # 内容预览
            })
            ids.append(chunk['id'])
        
        # 存储到Qdrant
        try:
            self.vector_store.add_vectors(vectors, metadatas, ids)
            self.stats['vectors_created'] += len(vectors)
            self.logger.info(f"存储了 {len(vectors)} 个向量到Qdrant")
        except Exception as e:
            self.logger.error(f"向量存储失败: {e}")
    
    def print_statistics(self) -> None:
        """打印统计信息"""
        self.logger.info("=== 处理统计信息 ===")
        for key, value in self.stats.items():
            self.logger.info(f"{key}: {value}")
        
        # 从数据库获取详细统计
        db_stats = self.db.get_statistics()
        self.logger.info("=== 数据库统计信息 ===")
        for key, value in db_stats.items():
            self.logger.info(f"{key}: {value}")
        
        # 获取向量数据库信息
        vector_info = self.vector_store.get_collection_info()
        self.logger.info("=== 向量数据库信息 ===")
        for key, value in vector_info.items():
            self.logger.info(f"{key}: {value}")
    
    async def run(self) -> None:
        """运行完整处理流程"""
        try:
            self.logger.info("开始NetOperatorQA数据集处理...")
            
            # 处理文档
            await self.process_documents()
            
            # 打印统计信息
            self.print_statistics()
            
            self.logger.info("NetOperatorQA数据集处理完成!")
            
        except Exception as e:
            self.logger.error(f"处理过程中发生错误: {e}")
            raise
        finally:
            self.db.close()


async def main():
    """主函数"""
    config_path = "config.toml"
    processor = NetOperatorQAProcessor(config_path)
    await processor.run()


if __name__ == "__main__":
    asyncio.run(main())