"""
独立的数据库操作模块
适配init.sql中的表结构
"""

import psycopg2
from psycopg2.extras import RealDictCursor
import uuid
import hashlib
import json
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
import logging


class DatabaseManager:
    """数据库管理器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config['database']
        self.workspace_id = config['processing']['workspace_id']
        self.logger = logging.getLogger(__name__)
        self.conn = None
        self._connect()
    
    def _connect(self):
        """连接数据库"""
        try:
            self.conn = psycopg2.connect(
                host=self.config['host'],
                port=self.config['port'],
                database=self.config['database'],
                user=self.config['username'],
                password=self.config['password']
            )
            self.conn.autocommit = True
            self.logger.info("数据库连接成功")
        except Exception as e:
            self.logger.error(f"数据库连接失败: {e}")
            raise
    
    def _generate_uuid(self) -> str:
        """生成UUID"""
        return str(uuid.uuid4())
    
    def _generate_md5(self, content: str) -> str:
        """生成MD5哈希"""
        return hashlib.md5(content.encode('utf-8')).hexdigest()
    
    def init_workspace(self) -> None:
        """初始化工作空间"""
        with self.conn.cursor() as cur:
            # 检查工作空间是否存在
            cur.execute("SELECT id FROM rag_workspace WHERE id = %s", (self.workspace_id,))
            if not cur.fetchone():
                cur.execute("""
                    INSERT INTO rag_workspace (id, doc_size, create_time, update_time)
                    VALUES (%s, %s, %s, %s)
                """, (self.workspace_id, 0, datetime.now(), datetime.now()))
                self.logger.info(f"创建工作空间: {self.workspace_id}")
    
    def insert_document(self, doc_name: str, content: str, meta: Dict[str, Any]) -> str:
        """插入文档"""
        doc_id = self._generate_uuid()
        md5_hash = self._generate_md5(content)
        file_size = len(content.encode('utf-8'))
        tokens = len(content) // 4  # 粗略估算
        
        with self.conn.cursor() as cur:
            cur.execute("""
                INSERT INTO rag_doc 
                (id, queue, workspace_id, doc_name, md5, file_size, content, 
                 extract_method, meta, status, tokens, create_time, update_time)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (doc_id, 'default', self.workspace_id, doc_name, md5_hash, 
                  file_size, content, 'auto', json.dumps(meta), 1, tokens, 
                  datetime.now(), datetime.now()))
        
        return doc_id
    
    def insert_chunk(self, doc_id: str, content: str, order_index: int) -> str:
        """插入文档块"""
        chunk_id = self._generate_uuid()
        tokens = len(content) // 4
        
        with self.conn.cursor() as cur:
            cur.execute("""
                INSERT INTO rag_doc_chunk 
                (id, workspace_id, doc_id, chunk_order_index, tokens, content, 
                 create_time, update_time)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (chunk_id, self.workspace_id, doc_id, order_index, tokens, 
                  content, datetime.now(), datetime.now()))
        
        return chunk_id
    
    def insert_entity(self, doc_id: str, chunk_id: str, entity_name: str, 
                     entity_type: str, description: str = "") -> str:
        """插入实体"""
        entity_id = self._generate_uuid()
        
        with self.conn.cursor() as cur:
            # 检查是否已存在相同实体
            cur.execute("""
                SELECT id, description FROM rag_doc_chunk_entity 
                WHERE workspace_id = %s AND doc_id = %s AND entity_name = %s AND entity_type = %s
            """, (self.workspace_id, doc_id, entity_name, entity_type))
            
            existing = cur.fetchone()
            if existing:
                # 合并描述
                existing_desc = existing[1] or ""
                if description and description not in existing_desc:
                    merged_desc = f"{existing_desc}<SEQ>{description}" if existing_desc else description
                    cur.execute("""
                        UPDATE rag_doc_chunk_entity 
                        SET description = %s, update_time = %s
                        WHERE id = %s
                    """, (merged_desc, datetime.now(), existing[0]))
                return existing[0]
            else:
                # 插入新实体
                cur.execute("""
                    INSERT INTO rag_doc_chunk_entity 
                    (id, workspace_id, doc_id, chunk_id, entity_name, entity_type, 
                     description, create_time, update_time)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (entity_id, self.workspace_id, doc_id, chunk_id, 
                      entity_name, entity_type, description, datetime.now(), datetime.now()))
                return entity_id
    
    def insert_relation(self, doc_id: str, chunk_id: str, src_entity: str, 
                       tgt_entity: str, relation_type: str, weight: float = 0.0, 
                       description: str = "") -> str:
        """插入关系"""
        relation_id = self._generate_uuid()
        
        with self.conn.cursor() as cur:
            # 检查是否已存在相同关系
            cur.execute("""
                SELECT id, weight, description FROM rag_doc_chunk_relation 
                WHERE workspace_id = %s AND doc_id = %s AND chunk_id = %s 
                AND src_entity_name = %s AND tgt_entity_name = %s AND keywords = %s
            """, (self.workspace_id, doc_id, chunk_id, src_entity, tgt_entity, relation_type))
            
            existing = cur.fetchone()
            if existing:
                # 更新权重和描述
                new_weight = max(existing[1] or 0.0, weight)
                existing_desc = existing[2] or ""
                if description and description not in existing_desc:
                    merged_desc = f"{existing_desc}<SEQ>{description}" if existing_desc else description
                else:
                    merged_desc = existing_desc
                
                cur.execute("""
                    UPDATE rag_doc_chunk_relation 
                    SET weight = %s, description = %s, update_time = %s
                    WHERE id = %s
                """, (new_weight, merged_desc, datetime.now(), existing[0]))
                return existing[0]
            else:
                # 插入新关系
                cur.execute("""
                    INSERT INTO rag_doc_chunk_relation 
                    (id, workspace_id, doc_id, chunk_id, src_entity_name, tgt_entity_name, 
                     keywords, weight, description, create_time, update_time)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (relation_id, self.workspace_id, doc_id, chunk_id,
                      src_entity, tgt_entity, relation_type, weight, description,
                      datetime.now(), datetime.now()))
                return relation_id
    
    def calculate_entity_degrees(self, doc_id: str) -> None:
        """计算实体度信息"""
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            # 计算每个实体的出度
            cur.execute("""
                SELECT src_entity_name as entity_name, COUNT(*) as out_degree
                FROM rag_doc_chunk_relation 
                WHERE workspace_id = %s AND doc_id = %s
                GROUP BY src_entity_name
            """, (self.workspace_id, doc_id))
            
            entity_degrees = cur.fetchall()
            
            if not entity_degrees:
                return
            
            # 计算排名
            max_degree = max(ed['out_degree'] for ed in entity_degrees)
            
            for entity_degree in entity_degrees:
                degree_rank = entity_degree['out_degree'] / max_degree if max_degree > 0 else 0.0
                
                # 插入度信息
                degree_id = self._generate_uuid()
                cur.execute("""
                    INSERT INTO rag_doc_entity_degree 
                    (id, workspace_id, doc_id, entity_name, out_degree, out_degree_rank, create_time)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT DO NOTHING
                """, (degree_id, self.workspace_id, doc_id, entity_degree['entity_name'],
                      entity_degree['out_degree'], degree_rank, datetime.now()))
    
    def update_document_status(self, doc_id: str, status: int, chunks_size: int) -> None:
        """更新文档状态"""
        with self.conn.cursor() as cur:
            cur.execute("""
                UPDATE rag_doc 
                SET status = %s, chunks_size = %s, processed_chunks_size = %s, 
                    process_during_time = 0, update_time = %s
                WHERE id = %s
            """, (status, chunks_size, chunks_size, datetime.now(), doc_id))
    
    def update_workspace_doc_count(self) -> None:
        """更新工作空间文档数量"""
        with self.conn.cursor() as cur:
            cur.execute("""
                SELECT COUNT(*) FROM rag_doc WHERE workspace_id = %s
            """, (self.workspace_id,))
            doc_count = cur.fetchone()[0]
            
            cur.execute("""
                UPDATE rag_workspace 
                SET doc_size = %s, update_time = %s
                WHERE id = %s
            """, (doc_count, datetime.now(), self.workspace_id))
    
    def get_chunks_for_retrieval(self, limit: int = 1000) -> List[Dict[str, Any]]:
        """获取用于检索的文档块"""
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT 
                    c.id,
                    c.content,
                    d.doc_name,
                    c.chunk_order_index
                FROM rag_doc_chunk c
                JOIN rag_doc d ON c.doc_id = d.id
                WHERE d.workspace_id = %s
                ORDER BY d.create_time, c.chunk_order_index
                LIMIT %s
            """, (self.workspace_id, limit))
            
            return [dict(row) for row in cur.fetchall()]
    
    def search_chunks_by_text(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """通过文本搜索块"""
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT 
                    c.id,
                    c.content,
                    d.doc_name,
                    similarity(c.content, %s) as score
                FROM rag_doc_chunk c
                JOIN rag_doc d ON c.doc_id = d.id
                WHERE d.workspace_id = %s
                AND similarity(c.content, %s) > 0.1
                ORDER BY score DESC
                LIMIT %s
            """, (query, self.workspace_id, query, limit))
            
            return [dict(row) for row in cur.fetchall()]
    
    def search_chunks_by_entities(self, entity_names: List[str], limit: int = 10) -> List[Dict[str, Any]]:
        """通过实体搜索块"""
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT DISTINCT
                    c.id,
                    c.content,
                    d.doc_name,
                    COUNT(e.entity_name) as entity_match_count
                FROM rag_doc_chunk c
                JOIN rag_doc d ON c.doc_id = d.id
                JOIN rag_doc_chunk_entity e ON c.id = e.chunk_id
                WHERE d.workspace_id = %s
                AND e.entity_name = ANY(%s)
                GROUP BY c.id, c.content, d.doc_name
                ORDER BY entity_match_count DESC
                LIMIT %s
            """, (self.workspace_id, entity_names, limit))
            
            return [dict(row) for row in cur.fetchall()]
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            # 基本统计
            cur.execute("""
                SELECT 
                    COUNT(DISTINCT d.id) as total_docs,
                    COUNT(DISTINCT c.id) as total_chunks,
                    COUNT(DISTINCT e.id) as total_entities,
                    COUNT(DISTINCT r.id) as total_relations
                FROM rag_doc d
                LEFT JOIN rag_doc_chunk c ON d.id = c.doc_id
                LEFT JOIN rag_doc_chunk_entity e ON d.id = e.doc_id
                LEFT JOIN rag_doc_chunk_relation r ON d.id = r.doc_id
                WHERE d.workspace_id = %s
            """, (self.workspace_id,))
            
            stats = dict(cur.fetchone())
            return stats
    
    def close(self):
        """关闭数据库连接"""
        if self.conn:
            self.conn.close()