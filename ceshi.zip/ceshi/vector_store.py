"""
Qdrant向量数据库客户端
"""

from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct, Filter, FieldCondition, MatchValue
import logging
from typing import List, Dict, Any, Optional, Tuple
import uuid


class VectorStore:
    """向量存储管理器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config['vectordb']
        self.logger = logging.getLogger(__name__)
        
        # 初始化Qdrant客户端
        self.client = QdrantClient(
            host=self.config['host'],
            port=self.config['port']
        )
        
        self.collection_name = self.config['collection_name']
        self.vector_size = self.config['vector_size']
        
        # 创建集合
        self._create_collection()
    
    def _create_collection(self):
        """创建向量集合"""
        try:
            # 检查集合是否存在
            collections = self.client.get_collections().collections
            collection_names = [col.name for col in collections]
            
            if self.collection_name not in collection_names:
                self.client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config=VectorParams(
                        size=self.vector_size,
                        distance=Distance.COSINE
                    )
                )
                self.logger.info(f"创建向量集合: {self.collection_name}")
            else:
                self.logger.info(f"向量集合已存在: {self.collection_name}")
                
        except Exception as e:
            self.logger.error(f"创建向量集合失败: {e}")
            raise
    
    def add_vectors(self, vectors: List[List[float]], metadatas: List[Dict[str, Any]], 
                   ids: Optional[List[str]] = None) -> List[str]:
        """添加向量"""
        if ids is None:
            ids = [str(uuid.uuid4()) for _ in range(len(vectors))]
        
        points = []
        for i, (vector, metadata) in enumerate(zip(vectors, metadatas)):
            point = PointStruct(
                id=ids[i],
                vector=vector,
                payload=metadata
            )
            points.append(point)
        
        try:
            self.client.upsert(
                collection_name=self.collection_name,
                points=points
            )
            self.logger.info(f"添加了 {len(points)} 个向量点")
            return ids
        except Exception as e:
            self.logger.error(f"添加向量失败: {e}")
            raise
    
    def search_vectors(self, query_vector: List[float], top_k: int = 10, 
                      filter_conditions: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """搜索相似向量"""
        try:
            # 构建过滤条件
            query_filter = None
            if filter_conditions:
                conditions = []
                for key, value in filter_conditions.items():
                    conditions.append(FieldCondition(key=key, match=MatchValue(value=value)))
                query_filter = Filter(must=conditions)
            
            # 执行搜索
            search_result = self.client.search(
                collection_name=self.collection_name,
                query_vector=query_vector,
                query_filter=query_filter,
                limit=top_k,
                with_payload=True,
                with_vectors=False
            )
            
            # 格式化结果
            results = []
            for hit in search_result:
                result = {
                    'id': hit.id,
                    'score': hit.score,
                    'payload': hit.payload
                }
                results.append(result)
            
            return results
            
        except Exception as e:
            self.logger.error(f"向量搜索失败: {e}")
            return []
    
    def delete_vectors(self, ids: List[str]) -> bool:
        """删除向量"""
        try:
            self.client.delete(
                collection_name=self.collection_name,
                points_selector=ids
            )
            self.logger.info(f"删除了 {len(ids)} 个向量点")
            return True
        except Exception as e:
            self.logger.error(f"删除向量失败: {e}")
            return False
    
    def get_collection_info(self) -> Dict[str, Any]:
        """获取集合信息"""
        try:
            info = self.client.get_collection(self.collection_name)
            return {
                'name': info.config.params.vectors.size,
                'vectors_count': info.vectors_count,
                'indexed_vectors_count': info.indexed_vectors_count,
                'points_count': info.points_count
            }
        except Exception as e:
            self.logger.error(f"获取集合信息失败: {e}")
            return {}
    
    def clear_collection(self) -> bool:
        """清空集合"""
        try:
            self.client.delete_collection(self.collection_name)
            self._create_collection()
            self.logger.info(f"清空集合: {self.collection_name}")
            return True
        except Exception as e:
            self.logger.error(f"清空集合失败: {e}")
            return False