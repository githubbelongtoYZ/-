# NetOperatorQA 独立项目

这是一个完全独立的NetOperatorQA数据集处理和评估项目，不依赖KAG源代码，可以移植到任何具有PostgreSQL + Qdrant + OpenAI API环境的项目中。

## 项目特性

- ✅ **完全独立**: 不依赖KAG框架源代码
- ✅ **标准数据库**: 使用PostgreSQL标准表结构（基于init.sql）
- ✅ **向量存储**: 集成Qdrant向量数据库
- ✅ **OpenAI兼容**: 支持所有OpenAI API兼容的大模型服务
- ✅ **HotpotQA评估**: 使用F1分数等标准评估指标
- ✅ **完整流程**: 数据处理 → 索引构建 → 评估测试

## 环境要求

### 数据库
- PostgreSQL (已按init.sql创建表结构)
- Qdrant向量数据库

### API服务
- OpenAI兼容的LLM服务 (用于文本生成)
- OpenAI兼容的嵌入服务 (用于向量化)

### Python依赖
```bash
pip install psycopg2-binary qdrant-client openai toml numpy
```

## 快速开始

### 1. 配置文件设置

复制并修改配置文件：
```bash
cp config.toml.example config.toml
```

编辑 `config.toml`，设置你的数据库和API信息：

```toml
[database]
host = "localhost"
port = 5432
database = "your_database"
username = "your_username"
password = "your_password"

[qdrant]
host = "localhost"
port = 6333
collection_name = "netoperator_qa"
vector_size = 1024

[openai]
base_url = "http://your-api-server:8001/v1"
api_key = "your-api-key"
llm_model = "your-llm-model"
embedding_model = "your-embedding-model"

[dataset]
documents_path = "data/documents"  # MD文档目录
qa_pairs_path = "data/qa_pairs.json"  # 问答对文件

[processing]
workspace_id = "netoperator_qa_workspace"
```

### 2. 准备数据

将NetOperatorQA数据集放置到指定目录：
```
data/
├── documents/          # 170个MD文档
│   ├── AF001.md
│   ├── AT002.md
│   └── ...
└── qa_pairs.json      # 569个问答对
```

问答对JSON格式：
```json
[
    {
        "question": "问题内容",
        "answer": "答案内容"
    }
]
```

### 3. 运行项目

```bash
python main.py
```

选择相应功能：
- **1. 数据处理**: 处理MD文档，提取实体关系，生成向量
- **2. 索引构建**: 构建知识图谱索引，优化检索性能
- **3. 评估测试**: 使用HotpotQA标准评估问答性能
- **4. 完整流程**: 依次执行上述所有步骤
- **5. 测试连接**: 验证数据库和API连接

## 项目结构

```
kag/examples/ceshi/
├── config.toml              # 配置文件
├── main.py                  # 主入口程序
├── processor.py             # 数据处理器
├── indexer.py              # 索引构建器
├── evaluator.py            # 评估器
├── database.py             # 数据库管理
├── openai_client.py        # OpenAI客户端
├── vector_store.py         # 向量存储
└── README.md               # 说明文档
```

## 核心功能详解

### 数据处理器 (processor.py)

- **文档分块**: 智能分割MD文档，保持语义完整性
- **实体提取**: 使用LLM提取人名、组织、地点等实体
- **关系抽取**: 识别实体间的语义关系
- **向量化**: 生成文档块的向量表示
- **数据存储**: 存储到PostgreSQL和Qdrant

### 索引构建器 (indexer.py)

- **实体去重**: 合并重复实体，提高数据质量
- **重要性计算**: 基于TF-IDF计算实体重要性分数
- **实体聚类**: 基于共现关系进行实体聚类
- **关系索引**: 构建关系模式和路径索引
- **向量索引**: 优化向量检索性能

### 评估器 (evaluator.py)

采用HotpotQA评估标准：

- **精确匹配 (EM)**: 预测答案与标准答案完全匹配的比例
- **F1分数**: 基于词级别的精确率和召回率
- **精确率/召回率**: 预测答案的准确性指标
- **检索质量**: 评估相关文档检索的准确性
- **答案质量**: 使用LLM评估答案的整体质量
- **响应时间**: 系统性能指标

### 混合检索策略

评估器使用多种检索方法：

1. **向量检索**: 基于语义相似度
2. **关键词检索**: 基于PostgreSQL全文搜索
3. **实体检索**: 基于命名实体匹配
4. **综合排序**: 融合多种检索结果

## 评估结果

评估完成后会生成：

- `evaluation_results_YYYYMMDD_HHMMSS.json`: 详细评估结果
- `evaluation_summary_YYYYMMDD_HHMMSS.txt`: 评估摘要报告

主要指标包括：
- 精确匹配率 (Exact Match)
- F1分数 (F1 Score)
- 精确率 (Precision)
- 召回率 (Recall)
- 检索准确率
- 答案质量分数
- 平均响应时间

## 数据库表结构

项目使用以下PostgreSQL表（基于init.sql）：

- `rag_doc`: 文档表
- `rag_doc_chunk`: 文档块表
- `rag_doc_chunk_entity`: 实体表
- `rag_doc_chunk_relation`: 关系表

## 配置说明

### 数据处理配置
```toml
[processing]
workspace_id = "netoperator_qa_workspace"  # 工作空间ID
chunk_size = 500                           # 文档块大小
chunk_overlap = 50                         # 块重叠大小
batch_size = 10                           # 批处理大小
```

### 实体提取配置
```toml
[entity_extraction]
max_entities_per_chunk = 20               # 每块最大实体数
confidence_threshold = 0.7                # 置信度阈值
entity_types = ["PERSON", "ORG", "LOCATION", "PRODUCT"]
```

### 关系提取配置
```toml
[relation_extraction]
max_relations_per_chunk = 15              # 每块最大关系数
confidence_threshold = 0.6                # 置信度阈值
```

### 评估配置
```toml
[evaluation]
retrieval_top_k = 5                       # 检索Top-K
max_answer_length = 200                   # 最大答案长度
timeout_seconds = 30                      # 超时时间
```

## 故障排除

### 常见问题

1. **数据库连接失败**
   - 检查PostgreSQL服务是否启动
   - 验证数据库连接参数
   - 确认数据库表已创建

2. **Qdrant连接失败**
   - 检查Qdrant服务是否启动
   - 验证端口配置
   - 确认集合是否存在

3. **OpenAI API调用失败**
   - 检查API服务是否可用
   - 验证API密钥和模型名称
   - 确认网络连接

4. **内存不足**
   - 减少batch_size
   - 降低chunk_size
   - 使用样本评估而非全量评估

### 日志查看

日志文件位置：`logs/netoperator_qa.log`

可以通过修改配置文件中的日志级别来调整日志详细程度：
```toml
[logging]
level = "INFO"  # DEBUG, INFO, WARNING, ERROR
```

## 性能优化

1. **数据库优化**
   - 为常用查询字段创建索引
   - 调整PostgreSQL配置参数
   - 使用连接池

2. **向量检索优化**
   - 调整Qdrant集合参数
   - 使用适当的向量维度
   - 启用量化压缩

3. **批处理优化**
   - 增加batch_size（在内存允许的情况下）
   - 使用异步处理
   - 并行处理多个文档

## 扩展功能

项目设计为模块化，可以轻松扩展：

- **新的实体类型**: 修改entity_types配置
- **自定义评估指标**: 扩展evaluator.py
- **不同的向量模型**: 更换embedding_model
- **其他数据源**: 扩展processor.py

## 许可证

本项目基于原KAG项目许可证，用于学术研究和非商业用途。

## 联系方式

如有问题或建议，请通过以下方式联系：
- 提交Issue
- 发送邮件
- 项目讨论区

---

**注意**: 这是一个独立项目，可以完全脱离KAG框架运行。所有依赖都是标准的Python包，便于部署和维护。